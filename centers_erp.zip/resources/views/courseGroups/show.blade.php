@foreach($times as $time)
    <h1> {{ $time->day }}</h1>
@endforeach
