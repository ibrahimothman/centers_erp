this is the landing page ya ostaz nader
