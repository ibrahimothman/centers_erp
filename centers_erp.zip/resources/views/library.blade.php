<meta charset="UTF-8">
<meta name="viewport" content="width=device-width , initial-scale=1 , shrink-to-fit=no"/>
<!-- Custom fonts for this template-->
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
      rel="stylesheet">
<link href="/../../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

<!-- Custom styles for this template-->
<link href="/../../../css/sb-admin-rtl.css" rel="stylesheet">
<link href="/../../../css/styles.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.rtlcss.com/bootstrap/v4.2.1/css/bootstrap.min.css"
      integrity="sha384-vus3nQHTD+5mpDiZ4rkEPlnkcyTP+49BhJ4wJeJunw06ZAp+wzzeBPUXr42fi8If" crossorigin="anonymous">

<!-- Bootstrap CSS & js -->
<link rel="stylesheet" href="/css/bootstrap.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.rtlcss.com/bootstrap/v4.2.1/js/bootstrap.min.js"
        integrity="sha384-a9xOd0rz8w0J8zqj1qJic7GPFfyMfoiuDjC9rqXlVOcGO/dmRqzMn34gZYDTel8k"
        crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/58b9d7bcbd.js" crossorigin="anonymous"></script>