<?php $__env->startSection('content'); ?>
    <h1>Tests</h1>
    <?php if(count($tests) > 0): ?>
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1><?php echo e($test->name); ?></h1>
            <?php echo e(Form::open([
                'action'=>['StudentTestController@store','test_id' => $test->id,
                'student_id' => $student->id], 
                'method' => 'POST'])); ?>

    
                <?php echo e(Form::submit('enroll',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>


            <?php echo e(Form::open([
                'action'=>['StudentTestController@unEnroll','test_id' => $test->id,
                'student_id' => $student->id], 
                'method' => 'POST'])); ?>


                <?php echo e(Form::hidden('_method','DELETE')); ?>

    
                <?php echo e(Form::submit('unEnroll',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/studentTest/create.blade.php ENDPATH**/ ?>