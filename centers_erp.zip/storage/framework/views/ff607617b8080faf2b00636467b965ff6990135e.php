<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width , initial-scale=1 , shrink-to-fit=no"/>
    <!-- Bootstrap CSS & js -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/room_style.css">
    <title> view rooms</title>


    <link href="/../../../css/styles.css" rel="stylesheet">
    <!-- Custom fonts for this template-->

    <link href="<?php echo e(url('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(url('css/sb-admin-rtl.css')); ?>" rel="stylesheet">
    <link
        rel="stylesheet"
        href="https://cdn.rtlcss.com/bootstrap/v4.2.1/css/bootstrap.min.css"
        integrity="sha384-vus3nQHTD+5mpDiZ4rkEPlnkcyTP+49BhJ4wJeJunw06ZAp+wzzeBPUXr42fi8If"
        crossorigin="anonymous">
</head>
<body class="bg-light">
<div id="wrapper">
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="content-wrapper" class="d-flex flex-column">
    <?php echo $__env->make('operationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Begin Page Content -->

<div class="container text-center ">
    <div class="row">
        <div class=" col">
            <div class="card text-center">
                <div class="card-body">
                    <a class="add btn btn-outline-primary" href="<?php echo e(route('rooms.create')); ?>" type="button"> اضافه غرفه جديده</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container addRoom  px-5 py-5">
    <div class="row">
        <div class="col">
            <h2 class="text-primary ">الغرف</h2>
            <br>
        </div>
    </div>
    <!-- card -->
    <div class="row">
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" col-md-3  col-xs-1">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-text"><?php echo e($room->name); ?></h5>
                        <a href="<?php echo e(route('rooms.edit',$room->id)); ?>" class="text-primary">قراء المزيد</a>
                    </div>
                </div>
                <br>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!-- script-->
<script type="text/javascipt" src="/js/jQuery.js"></script>
<script type="text/javascript" src="/js/bootstrap.bundle.min.js"></script>
<script src="/js/jquery-3.3.1.min.js"></script>
<script src="/js/popper.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\ibrah\centers_erp\resources\views/rooms/rooms_view.blade.php ENDPATH**/ ?>