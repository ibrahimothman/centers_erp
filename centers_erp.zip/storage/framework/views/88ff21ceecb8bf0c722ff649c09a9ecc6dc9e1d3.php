<!DOCTYPE html>
<html lang="ar">
<head>
    <?php echo $__env->make('library', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="/css/instructor_style.css">

    <title>overview instructor</title>
    <style>

    </style>
</head>
<?php $Constants = app('App\helper\Constants'); ?>
<body class="bg-light">
<div id="wrapper">
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="content-wrapper" class="d-flex flex-column">
    <?php echo $__env->make('operationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Begin Page Content -->
<section>
    <!-- data -->
    <div class="container  text-right" style="background-color: #fff;">
        <br>
        <div class="row">
            <div class="  col-lg-4">

                <img class="profilePhoto" src="<?php echo e($instructor->image); ?>" style="">
            </div>
            <div class="  col-lg-8">
                <br>
                <br>
                <h5><?php echo e($instructor->nameAr); ?></h5>
                <p><?php echo e($instructor->nameEn); ?></p>
                <a href="#">السيره الذاتيه</a>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col">

            <h2 class="text-primary">نبذه عن</h2>
            <p><?php echo e($instructor->bio); ?></p>


            </div>
        </div>

        <hr>
        <!-- start courses -->
        <div class="row">
            <div class="col">
                <h2 class="text-primary">الكورسات </h2>
            </div>
        </div>

<!-- motion -->

    <!-- dishes -->

                <div class="spldishes-grids">
                    <!-- Owl-Carousel -->
                    <?php ($courses=$instructor->courses); ?>
                    <?php for($i=0;$i<count($courses);$i+=3): ?>
                    <div class="row pb-4">

                        <?php for($j=$i;$j<$i+3;$j++): ?>
                            <?php if($j==count($courses)): ?>
                                <?php break; ?>
                                <?php endif; ?>
                        <div class="col-lg-4">
                    <div id="owl-demo" class="owl-carousel text-center agileinfo-gallery-row">
                        <div class="item g1" style="padding-right: 10px;">
                            <img src="<?php echo e(count($courses[$j]->images)>0?$courses[$j]->images[0]->url:$Constants->getCoursePlaceholderImage()); ?>" style="height:400px;width: 100%" class="lazyOwl">
                            <div class="agile-dish-caption">
                                <h5 style="color: #007bff"><?php echo e($courses[$j]->name); ?> </h5>
                                <p style="height:100px; width: 100%; color: #fff">
                                    <?php echo e($courses[$j]->description); ?>

                                </p>
                                <a href="/courses/<?php echo e($courses[$j]->id); ?>">قراءه المزيد</a>
                            </div>
                        </div>
                    </div>
                            <br>
                        </div>
                        <?php endfor; ?>


                        <br>

                    </div>
                        <?php endfor; ?>

                </div>
                <br>

            </div>
        </div>

        <!-- end cards  -->
    </div>

    <!-- end container  -->
</section>
        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<!-- script-->

<?php echo $__env->make('script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\ibrah\centers_erp\resources\views/instructor/overview_instructor.blade.php ENDPATH**/ ?>