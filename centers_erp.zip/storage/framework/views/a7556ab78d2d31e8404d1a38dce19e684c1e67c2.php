<?php $__env->startSection('content'); ?>
    <h1>Available Tests</h1>
    <?php if(count($tests) > 0): ?>
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h1><?php echo e($test->name); ?></h1>
            <?php echo e(Form::open([
                'action'=>['StudentTestGroupController@showTestGroups'
                ,$student->id,$test->id], 
                'method' => 'GET'])); ?>

    
                <?php echo e(Form::submit('Show groups',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>


            

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\training_erp\resources\views/studentTestGroup/create.blade.php ENDPATH**/ ?>