
<footer class=" mt-auto sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy;وحدة التعليم الالكترونى - جامعه المنصورة </span>
        </div>
    </div>
</footer><?php /**PATH C:\Users\ibrah\centers_erp\resources\views/footer.blade.php ENDPATH**/ ?>