<!DOCTYPE html>
<html lang="ar">
<head>
    <?php echo $__env->make('library', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="/css/room_style.css">
    <link rel="stylesheet" href="/css/calendar.css">
    <title>room calendar</title>
  </head>
<body class="bg-light">
<div id="wrapper">
    <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="content-wrapper" class="d-flex flex-column">
    <?php echo $__env->make('operationBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Begin Page Content -->
<div class="container text-center ">
    <div class="row">
        <div class=" col">
            <div class="card  motionCard text-center">
                <div class="card-body">
                    <a class="add btn btn-outline-primary" href="#" type="button"> حجز موعد جديد</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Begin calendar -->
<div class="container calendarshow">
    <div class="row">
        <div class="col">
            <div id="calendarContainer"></div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <div id="organizerContainer" style="margin-top: 50px;"></div>
        </div>
    </div>
</div>
<br>

        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<!-- script-->

<?php echo $__env->make('script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="/js/calendar.js"></script>
</body>
</html>
<?php /**PATH C:\Users\ibrah\centers_erp\resources\views/rooms/room_calendar.blade.php ENDPATH**/ ?>