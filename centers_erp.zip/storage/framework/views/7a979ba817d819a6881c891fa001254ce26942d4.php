<?php $__env->startSection('content'); ?>
    <h1>Groups</h1>
    <?php if(count($groups) > 0): ?>
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Form::open([
                'action'=>['TestEnrollmentController@store'
                ,$studentId,$group->id], 
                'method' => 'POST'])); ?>


                <?php echo e(Form::label('id',$group->id)); ?>

                
    
                <?php echo e(Form::submit('create',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No groups found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\training_erp\resources\views/testsEnrollments/groups.blade.php ENDPATH**/ ?>