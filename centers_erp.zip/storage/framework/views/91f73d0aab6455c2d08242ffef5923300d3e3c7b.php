this is the landing page ya ostaz nader
<?php /**PATH C:\Users\ibrah\centers_erp\resources\views/home.blade.php ENDPATH**/ ?>