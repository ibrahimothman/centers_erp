

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet" type="text/css"/>

<div class="form-style-5">




    <form action="<?php echo e(route('groups.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <legend><span class="number">.</span> Group Registeration </legend>
        <input type="text" name="course" placeholder="course *" required>
        <input type="date"  name="startDate" placeholder="start date *" required>
        <input type="text" name="instructor" placeholder="course instructor *" required>
        <input name="add" type="submit" value="Add group" required />
    </form>


</div>
<span class="alert">
    <p class="message">
    <?php
    if(session()->has('message')){
        echo session()->get("message");
    }
    ?>
</p>
</span>

</html>

<?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/addGroup.blade.php ENDPATH**/ ?>