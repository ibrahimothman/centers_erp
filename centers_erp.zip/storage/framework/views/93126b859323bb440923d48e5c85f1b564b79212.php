<?php $__env->startSection('content'); ?>
    <h1>Edit Tets</h1>
    <?php echo Form::open(['action' => ['TestController@update', $test->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class = "form_group">
        <?php echo e(From::label('title','Test name')); ?>

        <?php echo e(Form::text('test_name',$test->name)); ?>

    </div>

    <div class = "form_group">
        <?php echo e(From::label('title','Test description')); ?>

        <?php echo e(Form::text('test_desc',$test->description)); ?>

    </div>

    <div class = "form_group">
        <?php echo e(From::label('title','Test cost')); ?>

        <?php echo e(Form::text('test_cost',$test->cost)); ?>

    </div>

    <div class = "form_group">
        <?php echo e(From::label('title','Test Date')); ?>

        <?php echo e(Form::text('test_date',$test->test_date)); ?>

    </div>

    <div class = "form_group">
        <?php echo e(From::label('title','retake')); ?>

        <?php echo e(Form::checkbox('retake','',$test->retake===0?false:true)); ?>

    
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Update', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/test/edit.blade.php ENDPATH**/ ?>