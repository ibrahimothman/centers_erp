

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet" type="text/css"/>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet"
          href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"
          type="text/css">

</head>

<body>
<div class="form-style-5">




    <form action="<?php echo e(route('groupStudents.store')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <legend><span class="number">.</span> Group Student Registeration </legend>
        <input type="text" id="studentName" name="studentName" placeholder="student *" required>
        <select name="course" >
            <option>select Course</option>
        <?php
            foreach ($Courses as $course){
                echo "<option>".$course->name."</option>";
            }
            ?>
        </select>

        <select  name="group" id="group" name="group" required>
            <option>select Group</option>
            <?php
            foreach ($groups as $group){
                echo "<option>".$group->id."</option>";
            }
            ?>
        </select>

        <input name="add" type="submit" value="register group student" required />
    </form>


</div>

<span class="alert">
    <p class="message">
    <?php
        if(session()->has('message')){
            echo session()->get("message");
        }
        ?>
</p>
</span>

<script>
    $(document).ready(function() {
        $( "#studentName" )
            .autocomplete({

            source: function(request, response) {
                $.ajax({
                    url: "<?php echo e(url('studentAutocomplete')); ?>",
                    data: {
                        term : request.term
                    },
                    dataType: "json",
                    success: function(data){
                        var resp = $.map(data,function(obj){
                            return {value: obj['nameEn'], id: obj['id']};
                        });

                        response(resp);
                    }
                });
            },
            minLength: 1,
                select: function(event, ui){
                    $('#studentName').val(ui.item.id);

                    return false;
                }
        });
    });



</script>
</body>
</html>


<?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/registerGroupStudent.blade.php ENDPATH**/ ?>