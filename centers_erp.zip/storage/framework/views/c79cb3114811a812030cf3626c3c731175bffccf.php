
<div class="form-row form-group">
    <div class="col-3 ">اسم الغرفه</div>
    <div class="col-9 ">
        <input type="text" value="<?php echo e(old('name') ?? $room->name); ?>" name="name" class='form-control'
               placeholder='ادخل اسم الغرفه'>
        <div><?php echo e($errors->first('name')); ?></div>
    </div>
</div>
<hr>
<div class="form-row form-group">
    <div class="col-3 ">الموقع</div>
    <div class="col-9 ">
        <input type="text" value="<?php echo e(old('location') ?? $room->location); ?>" name="location" class='form-control' placeholder='ادخل الموقع'>
        <div><?php echo e($errors->first('location')); ?></div>
    </div>

</div>
<h6>تفاصيل مساحه الغرفه</h6>
<div class="card ">
    <div class="card-body">
        <div class="form-row form-group">
            <div class="col-3 ">مساحه الغرفه</div>
            <div class="col-9 ">
                <input type="number" value="<?php echo e(old('area') ?? $room->details['area']); ?>" name="area" class='form-control' placeholder='المساحه بالمتر المربع'>
                <div><?php echo e($errors->first('area')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <div class="col-3 ">عدد الكراسي</div>
            <div class="col-9 ">
                <input type="number" value="<?php echo e(old('no_of_chairs') ?? $room->details['no_of_chairs']); ?>" name="no_of_chairs" class='form-control'
                       placeholder='ادخل عدد الكراسي'>
                <div><?php echo e($errors->first('no_of_chairs')); ?></div>
            </div>
        </div>
        <div class="form-row form-group">
            <div class="col-3 ">عدد الكمبيوتر</div>
            <div class="col-9 ">
                <input type="number" value="<?php echo e(old('no_of_computers') ?? $room->details['no_of_computers']); ?>" name="no_of_computers" class='form-control'
                       placeholder='ادخل عدد الكمبيوتر'>
                <div><?php echo e($errors->first('no_of_computers')); ?></div>
            </div>
        </div>
    </div>
</div>
<br>
<h6>محتويات الغرفه</h6>
<div class="card ">
    <div class="card-body">
        <div class="row ">
            <div class="col-md-3">
                <input name="extras[camera]" class="extra-class" type="checkbox" <?php echo e(! is_null($room->extras) && array_key_exists('camera',$room->extras) && $room->extras['camera'] == 'on' ? 'checked' : ''); ?>>
                <label>كاميرات مراقبه</label>
            </div>
            <div class="col-md-3">
                <input name="extras[air-conditioner]" class="extra-class" type="checkbox" <?php echo e(! is_null($room->extras) && array_key_exists('air-conditioner',$room->extras) && $room->extras['air-conditioner'] == 'on' ? 'checked' : ''); ?> >
                <label>تكيف</label>
            </div>
            <div class="col-md-3">
                <input name="extras[data-show]" class="extra-class" type="checkbox" <?php echo e(! is_null($room->extras) && array_key_exists('data-show',$room->extras) && $room->extras['data-show'] == 'on' ? 'checked' : ''); ?> >
                <label>دتاشو</label>
            </div>
            <div class="col-md-3">
                <input type="checkbox" onClick="selectAll(this)">
                <label>تحديد الكل</label>
            </div>
        </div>
    </div>
</div>
<br>


<script>
    function selectAll(source) {
        var checkboxes = document.getElementsByClassName('extra-class');
        for(var i=0, n=checkboxes.length;i<n;i++) {
            checkboxes[i].checked = source.checked;
        }
    }
</script>

<?php /**PATH C:\Users\ibrah\centers_erp\resources\views/rooms/form.blade.php ENDPATH**/ ?>