<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
<link href="<?php echo e(asset('css/form.css')); ?>" rel="stylesheet" type="text/css"/>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet"
          href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"
          type="text/css">

</head>

<body>
<div class="form-style-5">




    <form action="<?php echo e(route('testTakes.store')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <legend><span class="number">.</span> Test Take Registration </legend>
        <input type="text" id="studentName" name="studentName" placeholder="student *" required>
        <select id="test" name="test" onchange="check(this)">
            <option value="-1">select Test</option>
            ><?php

            ?>
        </select>

        <select  name="group" id="group"  name="group" required>
            <option >select Group</option>
        </select>

        <input name="add" type="submit" value="register group student" required />
    </form>


</div>

<span class="alert">
    <p class="message">
    <?php
        if(session()->has('message')){
            echo session()->get("message");
        }
        ?>
</p>
</span>

<script>
    $(document).ready(function() {
        $( "#studentName" )
            .autocomplete({

            source: function(request, response) {
                $.ajax({
                    url: "<?php echo e(url('studentAutocomplete')); ?>",
                    data: {
                        term : request.term
                    },
                    dataType: "json",
                    success: function(data){
                        var resp = $.map(data,function(obj){
                            return {value: obj['nameEn'], id: obj['id']};
                        });

                        response(resp);
                    }
                });
            },
            minLength: 1,
                select: function(event, ui){
                    $('#studentName').val(ui.item.id);

                    return false;
                }
        });
    });



</script>

<script>
    function check(element){
        //alert(element[element.selectedIndex].id);
        alert(element.value);
    }
</script>

</body>
</html>


<?php /**PATH C:\Users\ibrah\training_erp\resources\views/testTakes/addTestTake.blade.php ENDPATH**/ ?>