<?php


namespace App\Http;


class TestResult
{

}
