<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\CourseGroup;
use Faker\Generator as Faker;

$factory->define(CourseGroup::class, function (Faker $faker) {
    return [
        //
    ];
});
