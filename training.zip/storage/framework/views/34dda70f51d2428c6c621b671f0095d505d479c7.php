<?php $__env->startSection('content'); ?>
    <h1>Tests</h1>
    <?php if(count($tests) > 0): ?>
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <div class="row">

                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/Test/<?php echo e($test->id); ?>"><?php echo e($test->name); ?></a></h3>
                        <small>Description : <?php echo e($test->description); ?> , COST :  <?php echo e($test->cost); ?> EGP</small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No tests found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\training_erp\resources\views/test/all.blade.php ENDPATH**/ ?>
