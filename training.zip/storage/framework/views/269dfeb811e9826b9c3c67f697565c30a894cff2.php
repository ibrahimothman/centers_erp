<?php $__env->startSection('content'); ?>
    <?php if(!is_null($student)): ?>
        <a href="/Student" class="btn btn-default">Go Back</a>
        <h1><?php echo e($student->nameEn); ?></h1>
        <br><br>
        
        <hr>
        <small>email : <?php echo e($student->email); ?></small>
        <hr>
        <hr>
        <small>phone Number : <?php echo e($student->phoneNumber); ?></small>
        <hr>
        
        <a href="/Student/<?php echo e($student->id); ?>/edit" class="btn btn-default">Edit</a>
        <?php echo Form::open([
            'action' => ['StudentController@destroy', $student->id],
             'method' => 'POST', 
             'class' => 'pull-right'
             ]); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>


        <br><br>

        <?php echo Form::open([
            'action' => ['StudentController@getEnrolledGroups',$student->id],
            'method' => 'GET'
            ]); ?>

                    
            <?php echo e(Form::submit('Tests in which you enrolled', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?> 
        <br><br>

        <?php echo Form::open([
            'action' => ['TestEnrollmentController@create',$student->id],
            'method' => 'GET'
            ]); ?>

                    
            <?php echo e(Form::submit('Enroll in new test', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>       
    <?php else: ?>
        <p>student not found</p>      
    <?php endif; ?>    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\training_erp\resources\views/student/profile.blade.php ENDPATH**/ ?>
