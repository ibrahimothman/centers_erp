<?php $__env->startSection('content'); ?>
    <?php if(!is_null($test)): ?>
        <a href="/Test" class="btn btn-default">Go Back</a>
        <h1><?php echo e($test->name); ?></h1>
        <br><br>
        
        <hr>
        <small>Description : <?php echo e($test->description); ?></small>
        <hr>
        <hr>
        <small>Cost : <?php echo e($test->cost); ?> EGP</small>
        <hr>
        <hr>
        <small>Date : <?php echo e($test->test_date); ?></small>
        <hr>
        <hr>
        <small>Retake : <?php echo e($test->retake==1? 'Yes':'No'); ?></small>
        <hr>
        <a href="/Test/<?php echo e($test->id); ?>/edit" class="btn btn-default">Edit</a>
        <?php echo Form::open([
            'action' => ['TestController@destroy', $test->id],
             'method' => 'POST', 
             'class' => 'pull-right'
             ]); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>


        <br><br>

        <?php echo Form::open([
            'action' => ['TestGroupController@getTestGroups',$test->id],
            'method' => 'GET'
            ]); ?>

                    
            <?php echo e(Form::submit('Groups', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>        
    <?php else: ?>
        <p>test not found</p>      
    <?php endif; ?>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/test/profile.blade.php ENDPATH**/ ?>
