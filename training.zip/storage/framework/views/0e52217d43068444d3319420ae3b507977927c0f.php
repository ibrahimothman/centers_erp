<?php $__env->startSection('content'); ?>
    <h1>Groups</h1>
    <?php if(count($testGroups) > 0): ?>
        <?php $__currentLoopData = $testGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Form::open([
                'action'=>['StudentTestGroupController@store'
                ,$studentId,$group->id],
                'method' => 'POST'])); ?>


                <?php echo e(Form::label('titel','date')); ?>

                <?php echo e(From::label('test_group_date',$group->group_date)); ?>



                <?php echo e(Form::label('titel','chairs')); ?>

                <?php echo e(From::label('test_group_chairs',$group->available_chairs)); ?>


                <?php echo e(Form::label('titel','hall')); ?>

                <?php echo e(From::label('test_group_hall',$group->hall_number)); ?>


                <?php echo e(Form::submit('enroll now',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No tests groups found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/studentTestGroup/all.blade.php ENDPATH**/ ?>
