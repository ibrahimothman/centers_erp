<?php $__env->startSection('content'); ?>
            
        <hr>
        <small>data : <?php echo e($testGroup->group_date); ?></small>
        <hr>
        <hr>
        <small>chairs : <?php echo e($testGroup->available_chairs); ?></small>
        <hr>
        <hr>
        <small>hall : <?php echo e($testGroup->hall_number); ?></small>
        <hr>
        
        <a href="/test_group/<?php echo e($testGroup->id); ?>/edit" class="btn btn-default">Edit</a>
        <?php echo Form::open([
            'action' => ['TestGroupController@destroy', $testGroup->id],
             'method' => 'POST', 
             'class' => 'pull-right'
             ]); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>


        <br><br>

          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrah\training_erp\resources\views/testGroup/profile.blade.php ENDPATH**/ ?>
