<h1>Create a test group</h1>

<?php echo e(Form::open([
        'action'=>['TestGroupController@store'],
        'method' => 'POST'])); ?>


<?php echo e(Form::label('title','select a test')); ?>

<?php echo e(Form::select('selected_test',$testsNames)); ?>


<?php echo e(Form::label('titel','select date')); ?>

<?php echo e(From::text('test_group_date')); ?>



<?php echo e(Form::label('titel','chairs')); ?>

<?php echo e(From::number('test_group_chairs')); ?>


<?php echo e(Form::label('titel','select hall')); ?>

<?php echo e(From::text('test_group_hall')); ?>


<?php echo e(Form::submit('create',['class' => 'btn btn-primary'])); ?>

<?php echo e(Form::close()); ?>

<?php /**PATH C:\Users\ibrah\training_erp\resources\views/testGroup/create.blade.php ENDPATH**/ ?>