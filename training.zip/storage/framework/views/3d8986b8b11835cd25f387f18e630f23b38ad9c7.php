
<h1> create a Test</h1>

<?php echo e(Form::open(['action' =>'TestController@store', 'method' => 'POST'])); ?>

    <div class = "form_group">
    	<?php echo e(From::label('title','Test name')); ?>

    	<?php echo e(Form::text('test_name')); ?>

    </div>

    <div class = "form_group">
    	<?php echo e(From::label('title','Test description')); ?>

    	<?php echo e(Form::text('test_desc')); ?>

    </div>

    <div class = "form_group">
    	<?php echo e(From::label('title','Test cost')); ?>

    	<?php echo e(Form::text('test_cost')); ?>

    </div>

    <div class = "form_group">
    	<?php echo e(From::label('title','retake')); ?>

    	<?php echo e(Form::checkbox('retake')); ?>

    </div>

    <?php echo e(Form::submit('Save Test',['class' => 'btn btn-primary'])); ?>

<?php echo e(Form::close()); ?>


<?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/Test/create.blade.php ENDPATH**/ ?>