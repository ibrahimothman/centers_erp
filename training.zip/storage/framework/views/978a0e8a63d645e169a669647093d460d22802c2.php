    <?php $__env->startSection('content'); ?>
        <h1>Edit The Group</h1>

        <?php echo e(Form::open([
                'action'=>['TestGroupController@update',$testGroup->id], 
                'method' => 'POST'])); ?>


                <?php echo e(Form::label('titel','date')); ?>

                <?php echo e(From::text('test_group_date',$testGroup->group_date)); ?>



                <?php echo e(Form::label('titel','chairs')); ?>

                <?php echo e(From::number('test_group_chairs',$testGroup->available_chairs)); ?>


                <?php echo e(Form::label('titel','select hall')); ?>

                <?php echo e(From::text('test_group_hall',$testGroup->hall_number)); ?>

    
                <?php echo e(Form::hidden('_method','PUT')); ?>

                <?php echo e(Form::submit('update',['class' => 'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>


    <?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/testGroup/edit.blade.php ENDPATH**/ ?>