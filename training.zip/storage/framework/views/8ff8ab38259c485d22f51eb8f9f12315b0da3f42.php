<?php $__env->startSection('content'); ?>
    <h1>Groups</h1>
    <?php if(count($testGroups) > 0): ?>
        <?php $__currentLoopData = $testGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <div class="row">

                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/test_group/<?php echo e($group->id); ?>"><?php echo e($group->id); ?></a></h3>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No tests groups found</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ibrakarim\training_erp\resources\views/testGroup/all.blade.php ENDPATH**/ ?>
