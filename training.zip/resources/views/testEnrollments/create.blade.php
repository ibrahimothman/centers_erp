@extends('layouts.app')

@section('content')
    <h1>Available Tests</h1>
    @if(count($tests) > 0)
        @foreach($tests as $test)
            <h1>{{$test->name}}</h1>
            {{ Form::open([
                'action'=>['TestEnrollmentController@showTestGroups'
                ,$student->id,$test->id], 
                'method' => 'GET']) }}
    
                {{Form::submit('Show groups',['class' => 'btn btn-primary'])}}
            {{  Form::close() }}

            

        @endforeach
    @else
        <p>No posts found</p>
    @endif


