@extends('layouts.app')

@section('content')
    <h1>Groups</h1>
    @if(count($testGroups) > 0)
        @foreach($testGroups as $group)
            {{ Form::open([
                'action'=>['StudentTestGroupController@store'
                ,$studentId,$group->id], 
                'method' => 'POST']) }}

                {{Form::label('titel','date')}}
                {{From::label('test_group_date',$group->group_date)}}


                {{Form::label('titel','chairs')}}
                {{From::label('test_group_chairs',$group->available_chairs)}}

                {{Form::label('titel','hall')}}
                {{From::label('test_group_hall',$group->hall_number)}}
    
                {{Form::submit('enroll now',['class' => 'btn btn-primary'])}}
            {{  Form::close() }}
        @endforeach
    @else
        <p>No tests groups found</p>
    @endif
@endsection