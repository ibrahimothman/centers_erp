@extends('layouts.app')

@section('content')
    <h1>Tests</h1>
    @if(count($tests) > 0)
        @foreach($tests as $test)
            <div class="well">
                <div class="row">
                
                    <div class="col-md-8 col-sm-8">
                        <h3><a href="/Test/{{$test->id}}">{{$test->name}}</a></h3>
                        <small>Description : {{$test->description}} , COST :  {{$test->cost}} EGP</small>
                    </div>
                </div>
            </div>
        @endforeach
    @else
        <p>No tests found</p>
    @endif
@endsection