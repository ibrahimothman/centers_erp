<h1>Create a test group</h1>

{{ Form::open([
        'action'=>['TestGroupController@store'],
        'method' => 'POST']) }}

{{Form::label('title','select a test')}}
{{Form::select('selected_test',$testsNames)}}

{{Form::label('titel','select date')}}
{{From::text('test_group_date')}}


{{Form::label('titel','chairs')}}
{{From::number('test_group_chairs')}}

{{Form::label('titel','select hall')}}
{{From::text('test_group_hall')}}

{{Form::submit('create',['class' => 'btn btn-primary'])}}
{{  Form::close() }}
