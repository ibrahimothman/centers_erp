<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseMedia extends Model
{
    public $timestamps = false;

}
