<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Test;
use App\TestGroup;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\ValidationException;
use phpDocumentor\Reflection\Types\Null_;

class TestGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //echo 'test '.Input::get('test');
        //Input::get('test'
        $allTests = DB::table('tests')
            ->get();

        $tests = DB::table('tests');
        if (Input::get('test')!=null)
            $tests=$tests->where('id',Input::get('test'));
        $tests=$tests->paginate(10);

        $testGroups=array();
        for ($i=0;$i<count($tests->items());$i++){

            $groups=DB::table('test_groups')
                        ->orderBy('group_date','desc')
                        ->where('test_id',$tests->items()[$i]->id)
                        ->get();
            for ($j=0;$j<count($groups);$j++){
                $groups[$j]->available_seats=
                    $groups[$j]->available_chairs - Db::table('test_enrollments')
                    ->where('test_group_id',$groups[$j]->id)
                    ->count();
            }

            $testGroups[]=$groups;


        }

        return view('testGroup.test-time-view')
            ->with('tests',$tests)
            ->with('allTests',$allTests)
            ->with('testGroups',$testGroups);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $tests = Test::orderBy('created_at','desc')->paginate(10);
//        $testsNames = array();
//        foreach ($tests as $test) {
//            $testsNames[$test->id] = $test->name;
//        }

        return view('testGroup.test-time-add')->with('tests',$tests);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //
//        $this->validate($request,[
//            'test' => 'required',
//            'test_time' => 'required',
//            'seat' => 'required',
//
//        ]);
//
//        $testId = $request->input('test');
//        $date = $request->input('test_time');
//        $seats = $request->input('seat');
//
//
//
//        $testGroup = new TestGroup;
//        $testGroup->test_id = $testId;
//        $testGroup->available_chairs = $seats;
//        $testGroup->group_date = $date;
        $this->validate($request,[
            'testName' => 'required',
            'test_time2' => 'required',
            'seat2' => 'required',

        ]);

        $test = $request->input('testName');
        $date = $request->input('test_time2');
        $seats = $request->input('seat2');


        $testId=DB::table('tests')
            ->where('name',$test)
            ->first();

        if ($testId==null)
            $this->throwValidationException(['test'=>'this test oes not exist']);


        $testGroup = new TestGroup;
        $testGroup->test_id = $testId->id;
        $testGroup->available_chairs = $seats;
        $testGroup->group_date = $date;

//        $testGroup = new TestGroup;
//        $testGroup->test_id = $testId;
//        $testGroup->available_chairs = $seats;
//        $testGroup->group_date = $date;

//        $testGroup->save();

        return $request->input('test');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // return $id;
        $testGroup = TestGroup::find($id);
        // $testGroup = DB::table('test_groups')->where('id',$id)->get();
        return view('testGroup.test-det-view-one')
            ->with('testGroup',$testGroup) ;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $testGroup = TestGroup::find($id);
        return view('testGroup.edit')->with('testGroup',$testGroup);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request,[
            'test_group_date' => 'required',
            'test_group_chairs' => 'required',
            'test_group_hall' => 'required'
        ]);
        $date = $request->input('test_group_date');
        $chairs = $request->input('test_group_chairs');
        $hall = $request->input('test_group_hall');

        $testGroup = TestGroup::find($id);
        $testGroup->available_chairs = $chairs;
        $testGroup->hall_number = $hall;
        $testGroup->group_date = $date;
        $testGroup->save();

        return redirect('/test_group/'.$testGroup->id)->with('sucsess','group updated');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $testGroup = TestGroup::find($id);
        $testGroup->delete();
        return redirect('/test_group')
            ->with('message','test group deleted successfully');

    }

    /**
     * Get all test groups.
     *
     * @param  int $testId
     * @return \Illuminate\Http\Response
     */
    public function getTestGroups(Request $request, $testId)
    {
        //

        $groups = DB::table('test_groups')->where('test_id',$testId)->get();
        return view('testGroup.index')->with('testGroups',$groups);


    }

    private function throwValidationException(array $errors){
        $error = ValidationException::withMessages($errors);
        throw $error;
    }
}
