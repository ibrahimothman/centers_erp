<?php

namespace App\Http\Controllers;

use App\StudentDetail;
use Illuminate\Http\Request;
use App\Student;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use phpDocumentor\Reflection\Types\Null_;
use Symfony\Component\HttpFoundation\File\File;


class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $students = DB::table('users')
            ->orderBy('created_at','desc')
            ->join('student_details', 'users.id', '=', 'student_details.student_id')
            ->get();


        return view('student.all')->with('students',$students);
    }

    public function viewAll(){
        $students = DB::table('users')
            ->orderBy('created_at','desc')
            ->join('student_details', 'users.id', '=', 'student_details.student_id')
            ;


        return response()->json($students);
    }

    /**
     * Display a listing of the resource as table.
     *
     * @return \Illuminate\Http\Response
     */
    public function showTable()
    {

        $students = Student::orderBy('id','asc')->get();
        return view('student.all-table')->with('students', $students);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('student.studentCreate');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

         //validate date before save it
        $this->validate($request,[
            'nameAr' => 'required',
            'nameEn' => 'required',
            'email' => 'required|email',
            'nationalIdNum' => 'required|digits:14',
            'state' => 'required',
            'picture' => 'required |image|file | max:10000',
            'idPicture' => 'required |image|file | max:10000',
            'phoneNumber' => 'required|regex:/(01)[0-9]{9}/'

        ]);



        $student = new Student;
        $student->nameAr = $request->input('nameAr');
        $student->nameEn = $request->input('nameEn');
        $student->email = $request->input('email');
        $student->phoneNumber = $request->input('phoneNumber');
        $student->idNumber = $request->input('nationalIdNum');
        $student->level = 0;

        $studentDetail =new StudentDetail();
        $studentDetail->passportNumber=$request->input('passportNum');
        $studentDetail->phoneNumberSec=$request->input('phoneNumberSec');
        $studentDetail->skillCardNumber=$request->input('skillcardNum');
        $studentDetail->state=$request->input('state');
        $studentDetail->city=$request->input('city');
        $studentDetail->address=$request->input('address');
        $studentDetail->degree=$request->input('degree');
        $studentDetail->faculty=$request->input('faculty');



        $this->ValidateInputs($student,$studentDetail,array());

        $idImg=$this->uploadImage($request,'idPicture');
        if ($idImg!=null)
            $student->nationalId = $this->getPath($idImg);
        $student->save();
        $lastId = $student->id;


        $studentDetail->student_id=$lastId;
        $profileImg=$this->uploadImage($request,'picture');
        if ($profileImg!=null)
            $studentDetail->picture=$this->getPath($profileImg);
        $studentDetail->save();



        return redirect("/Student/$lastId");

    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student = DB::table('users')
            ->join('student_details', 'users.id', '=', 'student_details.student_id')
            ->where('users.id',$id)
            ->first();

        //
        //$student = Student::find($id);
        return view('student.profile')->with('student', $student);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $student = DB::table('users')
            ->join('student_details', 'users.id', '=', 'student_details.student_id')
            ->where('users.id',$id)
            ->first();
        return view('student.studentEdit')->with('student',$student);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {


        $this->validate($request,[
            'nameAr' => 'required',
            'nameEn' => 'required',
            'email' => 'required|email',
            'nationalIdNum' => 'required|digits:14',
            'state' => 'required',
            'picture' => ' image|file | max:10000',
            'idPicture' => ' image|file | max:10000',
            'phoneNumber' => 'required|regex:/(01)[0-9]{9}/'

        ]);

        $oldStudent = Student::find($id);
        $student=new Student();
        $student->id=$oldStudent->id;
        $student->nameAr = $request->input('nameAr');
        $student->nameEn = $request->input('nameEn');
        $student->email = $request->input('email');
        $student->phoneNumber = $request->input('phoneNumber');
        $student->idNumber = $request->input('nationalIdNum');

        $oldDetails=DB::table('student_details')->where('student_id',$id)->first();

        $newDetails=new StudentDetail();
        $newDetails->passportNumber=$request->input('passportNumber');
        $newDetails->skillCardNumber=$request->input('skillCardNumber');
        $changes=$this->generateChangeArray($oldStudent,$student,$oldDetails,$newDetails);

        $this->ValidateInputs($student,$newDetails,$changes);
        //return;

       $studentUpdate=[
           'nameAr'=>$student->nameAr,
           'nameEn'=>$student->nameEn,
           'email'=>$student->email,
           'phoneNumber'=>$student->phoneNumber,
           'idNumber'=>$student->idNumber,
       ];
        $studentDetailsUpdate=[
            'passportNumber' => $request->input('passportNumber'),
            'phoneNumberSec' => $request->input('phoneNumberSec'),
            'skillCardNumber' => $request->input('skillCardNumber'),
            'state' => $request->input('state'),
            'city' => $request->input('city'),
            'address' => $request->input('address'),
            'degree' => $request->input('degree'),
            'faculty' => $request->input('faculty')
        ];

        if ($request->has('idPicture')){
            $idPicture=$this->uploadImage($request,'idPicture');
            if ($idPicture!=null)
                $studentUpdate['nationalId']=$this->getPath($idPicture);
        }
        if ($request->has('picture')){
            $Picture=$this->uploadImage($request,'picture');
            if ($Picture!=null)
                $studentDetailsUpdate['picture']=$this->getPath($Picture);
        }

        DB::table('users')->where('users.id',$id)
            ->update($studentUpdate);

        DB::table('student_details')->where('student_id',$id)->update($studentDetailsUpdate);


        return redirect('/Student/'.$id)->with('success','updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $student = Student::find($id);
        $student->delete();

        return redirect('/Student')->with('success','student is deleted');

    }

    /**
     * list all test that student have enrolled in.
     *
     * @param  int  $studentId
     * @return \Illuminate\Http\Response
     */
    public function getEnrolledGroups($studentId)
    {
        /*
        SELECT test_groups.id , test_groups.group_date, test_groups.hall_number, tests.name FROM test_groups INNER JOIN tests_enrollments ON test_groups.id = tests_enrollments.test_group_id
        INNER JOIN tests ON test_groups.test_id = tests.id
        WHERE tests_enrollments.student_id = 1
        */
        $enrolledGroups = DB::table('test_groups')
                    ->join('tests_enrollments', 'test_groups.id', '=', 'tests_enrollments.test_group_id')
                    ->join('tests','test_groups.test_id','=','tests.id')
                    ->select(
                        array('test_groups.id','test_groups.group_date'
                            ,'test_groups.hall_number','tests.name'))
                    ->where('tests_enrollments.student_id',$studentId)
                    ->get();

        foreach ($enrolledGroups as $group) {
            echo 'group_id = '.$group->id;
            echo "<br>";
            echo 'group_date = '.$group->group_date;
            echo "<br>";
            echo 'group_hall = '.$group->hall_number;
            echo "<br>";
            echo 'test_name = '.$group->name;
            echo "<br>";
        }

    }

    public function uploadImage(Request $request,$key){
        $file = Input::file($key);
        $imageName = time().'.'.$file->getClientOriginalExtension();

         return $file->move(public_path('/uploads'), $imageName);
    }

    private function ValidateInputs(Student $student, $studentDetail,array $changed){
        $errors=array();

        if (count($changed)===0||$changed[0]==true){
            $email=DB::table('users')
                ->where('users.email',$student->email)
                ->get();
            if ($email->isNotEmpty()){
                $errors['email']='this Email is already registered';
            }

        }

        if (count($changed)===0||$changed[1]==true) {

            $idNumber = DB::table('users')
                ->where('users.idNumber', $student->idNumber)
                ->get();
            if ($idNumber->isNotEmpty()){
                $errors['idNumber']='this id number is already registered';
            }
        }

        if (count($changed)===0||$changed[2]==true){

            if (isset($student->phoneNumber)){
            $phoneNumber=DB::table('users')
                ->where('users.phoneNumber',$student->phoneNumber)
                ->get();
            }

            if ($phoneNumber->isNotEmpty()){
                $errors['phoneNumber']='this phone number is already registered';
            }

        }

        if (count($changed)===0||$changed[3]==true){

            if (isset($studentDetail->passportNumber)) {
                $passportNumber = DB::table('student_details')
                    ->where('student_details.passportNumber', $studentDetail->passportNumber)
                    ->get();

                if ($passportNumber->isNotEmpty()) {
                    $errors['passportNumber'] = 'this passport number is already registered';
                }
            }

        }

        if (count($changed)===0||$changed[4]==true){
            if (isset($studentDetail->skillCardNumber)) {
                $skillCardNumber = DB::table('student_details')
                    ->where('student_details.skillCardNumber', $studentDetail->skillCardNumber)
                    ->get();

                if ($skillCardNumber->isNotEmpty()) {
                    $errors['skillCardNumber'] = 'this skillCard number is already registered';
                }
            }

        }

        if (count($errors)>0){
            $this->throwValidationException($errors);
        }

    }

    private function getPath(File $file){
        return url("/uploads/".pathinfo($file)['basename']);
    }

    private function throwValidationException(array $errors){
        $error = ValidationException::withMessages($errors);
        throw $error;
    }

    private function generateChangeArray(Student $oldStudent,Student $student,
                                    $oldStudentDetail,$StudentDetail){
        $changes=array(false,false,false,false,false);
        if ($oldStudent->email!=$student->email){
            $changes[0]=true;
        }
        if ($oldStudent->idNumber!=$student->idNumber){
            $changes[1]=true;
        }
        if ($oldStudent->phoneNumber!=$student->phoneNumber){
            $changes[2]=true;
        }

        if ($oldStudentDetail->passportNumber!=$StudentDetail->passportNumber){
            $changes[3]=true;
        }
        if ($oldStudentDetail->skillCardNumber!=$StudentDetail->skillCardNumber){
            $changes[4]=true;
        }
        return $changes;
    }
}
