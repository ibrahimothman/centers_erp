<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use App\Test;
use DB;
use App\TestsEnrollments;

class TestEnrollmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('testEnrollments.test-stu-view');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($studentId=null)
    {
        //
        //$student = Student::find($studentId);
        //$tests = DB::table('tests')->get();

            // return 'he has already enrolled in at least one test';
        return view('testEnrollments.test-stu-add');
            //->with('student',$student)->with('tests',$tests);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,$studentId,$groupId)
    {
        //
        $enroll = new TestsEnrollments;
        $enroll->student_id = $studentId;
        $enroll->test_group_id = $groupId;
        $enroll->save();

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    /**
     * Get all test groups for student.
     *
     * @param  int $studentId
     * @param  int $testId
     * @return \Illuminate\Http\Response
     */
    public function showTestGroups($studentId, $testId)
    {
        //

        $groups = DB::table('test_groups')
                        ->leftJoin('tests_enrollments', 'tests_enrollments.test_group_id', '=', 'test_groups.id')
                        ->select(array('test_groups.*'
                            , DB::raw('COUNT(tests_enrollments.student_id) as followers')))
                        ->where('test_groups.test_id',$testId)
                        ->groupBy('tests_enrollments.test_group_id')
                        ->get();
       return view('testEnrollments.groups')
                ->with('groups',$groups)->with('studentId',$studentId);


    }
}
