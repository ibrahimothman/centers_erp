<?php


namespace App\Http\Controllers;


use App\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LiveSearchController
{

    public function action(Request $request){
        if($request->ajax()){
            $query = $request->get('query');
            if($query != ''){
                $students = Db::table('users')
                                ->join('student_details', 'users.id', '=', 'student_details.student_id')
                                ->where('nameEn','like','%'.$query.'%')
                                ->get();
            }else{
                $students = Db::table('users')
                    ->join('student_details', 'users.id', '=', 'student_details.student_id')
                    ->get();
            }

        }
        return response()->json($students);
    }

}
