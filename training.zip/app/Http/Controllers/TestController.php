<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Test;
use DB;
class TestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $tests = Test::orderBy('created_at','desc')->paginate(10);
        return view('test.test-det-view')->with('tests', $tests);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('test.test-det-add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
//        $this->validate($request,[
//            'test_name' => 'required',
//            'test_desc' => 'required',
//            'test_cost' => 'required'
//
//        ]);

        // echo "string";
        // echo $request->has('retake');
        // echo $request->input('retake');

        $test = new Test;
        $test->name = $request->input('test_name');
        $test->description = $request->input('test-det');
        $test->cost_ind = $request->input('cost_ind');
        $test->cost_course = $request->input('cost_course');
        $test->retake = $request->input('rep_check') == null? 0 : 1;
        $test->save();
        return redirect('/test');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $test = Test::find($id);
        return view('test.test-det-view-one')->with('test',$test);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $test = Test::find($id);
        return view('test.test-det-edit')->with('test',$test);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

//        echo $request->input('cost_ind');
//        echo $request->input('cost_course');
        $test = Test::find($id);
        $test->name = $request->input('test_name');
        $test->description = $request->input('test-det');
        $test->cost_ind = $request->input('cost_ind');
        $test->cost_course = $request->input('cost_course');
        $test->retake = $request->input('rep_check') == null? 0 : 1;
        $test->save();
//        return 'updated';

//        return redirect('/test')->with('success','test updated');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $test = Test::find($id);
        $test->delete();

        return redirect('/test')->with('success','test is deleted');
    }

    /**
     * list all students enrolling in specefic test.
     *
     * @param  int  $testId
     * @return \Illuminate\Http\Response
     */
    public function getStudents($id)
    {

        // return 'listTestStudents';
        $students = DB::table('students')
            ->join('student_tests', 'students.id', '=', 'student_tests.student_id')
            ->where('student_tests.test_id',$id)
            ->get();
        return view('studentTest.show')->with('students',$students);
    }
    public function testTime(){
        // return 'test add time';
        return view ('testGroup.test-time-add');
    }
}
