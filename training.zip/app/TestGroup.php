<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TestGroup extends Model
{
    //
}
