<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('student.studentCreate');
});


Route::resource('courses','CoursesController');
Route::resource('Student','StudentController');
Route::get('Student-table','StudentController@showTable');
Route::resource('test','TestController');
Route::resource('StudentTest', 'StudentTestController',
    array('except' => array('create')));

Route::resource('groups','GroupController');
Route::resource('groupStudents','GroupStudentsController');
Route::get('studentAutocomplete', 'GroupStudentsController@search');
Route::get('test/{id}/enrollment','TestController@getStudents');
Route::get('student/{id}/enrollment','StudentController@getEnrolledGroups');
Route::delete('student/{student_id}/test/{tets_id}/unenrollment','StudentTestController@unEnroll');
Route::resource('test_group','TestGroupController');
Route::get('test/{test_name}/groups','TestGroupController@getTestGroups');

// student test group
Route::resource('test_enrollment','TestEnrollmentController');
Route::get('/student/{id?}/tests','TestEnrollmentController@create');
Route::get('/student/{sid}/test/{tid}/groups','TestEnrollmentController@showTestGroups');

Route::post('student/{sid}/enroll/{gid}','TestEnrollmentController@store');


Route::resource('testTakes','TestTakeControler');
Route::get('/add_test_time','TestController@testTime');
Route::get('/search','LiveSearchController@action');
Route::get('/Student/all','StudentController@viewAll');

